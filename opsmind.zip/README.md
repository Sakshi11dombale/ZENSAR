# OpsMind AI - Intelligent Command Center

OpsMind AI is a next-generation observability prototype designed to transform incident response using causal AI. It provides a unified view of system health, active incidents, and automated root cause analysis.

## 🚀 Quick Start

### 1. Prerequisites
- Node.js (v18 or higher)
- npm or yarn

### 2. Installation
```bash
npm install
```

### 3. Environment Setup
Create a `.env` file in the root directory and add your Gemini API Key:
```env
GEMINI_API_KEY=your_api_key_here
```
*Note: You can get an API key from [Google AI Studio](https://aistudio.google.com/app/apikey).*

### 4. Development
```bash
npm run dev
```

### 5. Build for Production
```bash
npm run build
```

## 🛠️ Features
- **Intelligent Dashboard**: Real-time pulse of infrastructure health.
- **AI Root Cause Analysis**: Automated hypothesis generation using Gemini.
- **System Map**: Interactive causal graph visualization.
- **Crisis Simulation**: One-click simulation of complex failure scenarios.
- **Video Generation**: Automated video summaries of incident analysis.

## 📦 Deployment (Vercel)
This project is a static Single Page Application (SPA) built with Vite and React.
1. Push this code to a GitHub repository.
2. Connect the repository to Vercel.
3. Add `GEMINI_API_KEY` to Vercel's Environment Variables.
4. Deploy!

---
Built with Google AI Studio Build.

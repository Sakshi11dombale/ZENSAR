export type IncidentStatus = 'active' | 'investigating' | 'resolved' | 'mitigated';
export type Severity = 'P1' | 'P2' | 'P3';

export interface Incident {
  id: string;
  title: string;
  status: IncidentStatus;
  severity: Severity;
  startTime: string;
  service: string;
  description: string;
  responders?: { name: string; avatar: string; role: string }[];
}

export interface RCAHypothesis {
  id: string;
  title: string;
  description: string;
  confidence: number; // 0 to 1
  impact: string;
  isSmokingGun?: boolean;
}

export interface LogEntry {
  timestamp: string;
  level: 'INFO' | 'ERROR' | 'WARN';
  service: string;
  message: string;
  isSmokingGun?: boolean;
  entities?: {
    type: 'IP' | 'SERVICE' | 'ERROR_CODE';
    value: string;
  }[];
}

export interface MetricPoint {
  time: string;
  value: number;
  isAnomaly?: boolean;
}

export interface GraphNode extends d3.SimulationNodeDatum {
  id: string;
  type: 'service' | 'database' | 'error' | 'fix';
  label: string;
  status?: 'healthy' | 'warning' | 'critical';
}

export interface GraphLink extends d3.SimulationLinkDatum<GraphNode> {
  source: string;
  target: string;
  value: number;
}

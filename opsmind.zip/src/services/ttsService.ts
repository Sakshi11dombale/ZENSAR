import { GoogleGenAI, Modality } from "@google/genai";
import * as lamejs from "lamejs";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function generateVoiceOver(text: string, voice: 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr' = 'Zephyr') {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      // Since it's raw PCM at 24000Hz, we use Web Audio API to play it.
      playRawPcm(base64Audio, 24000);
      return true;
    }
  } catch (error) {
    console.error("TTS Generation Error:", error);
  }
  return false;
}

export async function getVoiceOverBlob(text: string, voice: 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr' = 'Zephyr'): Promise<Blob | null> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      // The output is raw PCM 16-bit 24kHz. To make it a "standard" audio file for download,
      // we should ideally wrap it in a WAV header.
      return createWavBlob(base64Audio, 24000);
    }
  } catch (error) {
    console.error("TTS Generation Error:", error);
  }
  return null;
}

export async function getVoiceOverMp3Blob(text: string, voice: 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr' = 'Zephyr'): Promise<Blob | null> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      return encodeMp3(base64Audio, 24000);
    }
  } catch (error) {
    console.error("TTS Generation Error:", error);
  }
  return null;
}

function encodeMp3(base64Data: string, sampleRate: number) {
  console.log("Starting MP3 encoding for", base64Data.length, "bytes of base64 data");
  try {
    // Handle different import styles for lamejs
    const lame = (lamejs as any).default || (lamejs as any);
    
    if (typeof window !== 'undefined') {
      const g = window as any;
      // lamejs internals often rely on these being in the global scope
      if (!g.MPEGMode && lame.MPEGMode) g.MPEGMode = lame.MPEGMode;
      if (!g.Lame && lame.Lame) g.Lame = lame.Lame;
      if (!g.BitStream && lame.BitStream) g.BitStream = lame.BitStream;
      if (!g.VbrMode && lame.VbrMode) g.VbrMode = lame.VbrMode;
    }

    const byteCharacters = atob(base64Data);
    const buffer = new ArrayBuffer(byteCharacters.length);
    const byteArray = new Uint8Array(buffer);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteArray[i] = byteCharacters.charCodeAt(i);
    }

    // PCM 16-bit is 2 bytes per sample. Ensure we don't have a trailing byte.
    const numSamples = Math.floor(byteArray.length / 2);
    const samples = new Int16Array(buffer, 0, numSamples);
    
    console.log("Encoding", samples.length, "samples at", sampleRate, "Hz");
    
    const mp3encoder = new lame.Mp3Encoder(1, sampleRate, 128);
    const mp3Data: Uint8Array[] = [];

    const sampleBlockSize = 1152; // Standard MP3 frame size
    for (let i = 0; i < samples.length; i += sampleBlockSize) {
      const sampleChunk = samples.subarray(i, i + sampleBlockSize);
      const mp3buf = mp3encoder.encodeBuffer(sampleChunk);
      if (mp3buf.length > 0) {
        mp3Data.push(new Uint8Array(mp3buf));
      }
    }

    const mp3buf = mp3encoder.flush();
    if (mp3buf.length > 0) {
      mp3Data.push(new Uint8Array(mp3buf));
    }

    console.log("MP3 encoding finished. Total chunks:", mp3Data.length);
    return new Blob(mp3Data, { type: 'audio/mpeg' });
  } catch (error) {
    console.error("MP3 Encoding Error:", error);
    return null;
  }
}

function createWavBlob(base64Data: string, sampleRate: number) {
  const byteCharacters = atob(base64Data);
  const byteArray = new Uint8Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteArray[i] = byteCharacters.charCodeAt(i);
  }

  const wavHeader = new ArrayBuffer(44);
  const view = new DataView(wavHeader);

  /* RIFF identifier */
  writeString(view, 0, 'RIFF');
  /* file length */
  view.setUint32(4, 32 + byteArray.length, true);
  /* RIFF type */
  writeString(view, 8, 'WAVE');
  /* format chunk identifier */
  writeString(view, 12, 'fmt ');
  /* format chunk length */
  view.setUint32(16, 16, true);
  /* sample format (raw) */
  view.setUint16(20, 1, true);
  /* channel count */
  view.setUint16(22, 1, true);
  /* sample rate */
  view.setUint32(24, sampleRate, true);
  /* byte rate (sample rate * block align) */
  view.setUint32(28, sampleRate * 2, true);
  /* block align (channel count * bytes per sample) */
  view.setUint16(32, 2, true);
  /* bits per sample */
  view.setUint16(34, 16, true);
  /* data chunk identifier */
  writeString(view, 36, 'data');
  /* data chunk length */
  view.setUint32(40, byteArray.length, true);

  return new Blob([wavHeader, byteArray], { type: 'audio/wav' });
}

function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

async function playRawPcm(base64Data: string, sampleRate: number) {
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  const byteCharacters = atob(base64Data);
  const byteArray = new Uint8Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteArray[i] = byteCharacters.charCodeAt(i);
  }

  // PCM 16-bit is 2 bytes per sample
  const float32Array = new Float32Array(byteArray.length / 2);
  const dataView = new DataView(byteArray.buffer);

  for (let i = 0; i < float32Array.length; i++) {
    // Read as 16-bit signed integer (little endian) and normalize to [-1, 1]
    float32Array[i] = dataView.getInt16(i * 2, true) / 32768;
  }

  const audioBuffer = audioContext.createBuffer(1, float32Array.length, sampleRate);
  audioBuffer.getChannelData(0).set(float32Array);

  const source = audioContext.createBufferSource();
  source.buffer = audioBuffer;
  source.connect(audioContext.destination);
  source.start();
}

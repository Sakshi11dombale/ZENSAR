import { GoogleGenAI } from "@google/genai";

export async function generateDemoVideo(prompt: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
  
  try {
    let operation = await ai.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: prompt,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9'
      }
    });

    return operation;
  } catch (error) {
    console.error("Video Generation Error:", error);
    throw error;
  }
}

export async function checkVideoStatus(operation: any) {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
  try {
    const updatedOperation = await ai.operations.getVideosOperation({ operation });
    return updatedOperation;
  } catch (error) {
    console.error("Check Video Status Error:", error);
    throw error;
  }
}

export async function downloadVideo(uri: string) {
  const response = await fetch(uri, {
    method: 'GET',
    headers: {
      'x-goog-api-key': process.env.GEMINI_API_KEY || '',
    },
  });
  
  if (!response.ok) throw new Error('Failed to download video');
  
  return await response.blob();
}

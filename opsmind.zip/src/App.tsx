/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  Activity, 
  AlertCircle, 
  Clock, 
  ChevronRight, 
  Terminal, 
  Database, 
  Cpu, 
  Search,
  ShieldCheck,
  Zap,
  ArrowLeft,
  CheckCircle2,
  ExternalLink,
  FileText,
  Users,
  Filter,
  Flame,
  Download,
  Share2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { GoogleGenAI } from "@google/genai";
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

import { Incident, RCAHypothesis, LogEntry, MetricPoint } from './types';
import { MOCK_INCIDENTS, MOCK_LOGS, MOCK_METRICS, MOCK_GRAPH_DATA } from './mockData';
import { KnowledgeGraph } from './components/KnowledgeGraph';
import { generateDemoVideo, checkVideoStatus, downloadVideo } from './services/videoService';
import { Video, Loader2, Key } from 'lucide-react';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'analysis' | 'telemetry' | 'graph'>('dashboard');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [rcaResults, setRcaResults] = useState<RCAHypothesis[]>([]);
  const [isCrisisMode, setIsCrisisMode] = useState(false);
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [filterSmokingGuns, setFilterSmokingGuns] = useState(false);
  const [analysisStep, setAnalysisStep] = useState(0);
  const [incidents, setIncidents] = useState<Incident[]>(MOCK_INCIDENTS);
  const [logs, setLogs] = useState<LogEntry[]>(MOCK_LOGS);
  const [metrics, setMetrics] = useState<MetricPoint[]>(MOCK_METRICS);
  const [isBackendConnected, setIsBackendConnected] = useState(true);
  const [isVideoGenerating, setIsVideoGenerating] = useState(false);
  const [videoProgress, setVideoProgress] = useState<string | null>(null);

  const activeIncidents = useMemo(() => incidents.filter(i => i.status !== 'resolved'), [incidents]);
  const resolvedIncidents = useMemo(() => incidents.filter(i => i.status === 'resolved'), [incidents]);

  const analysisSteps = [
    "SCANNING DISTRIBUTED LOGS...",
    "CORRELATING METRIC ANOMALIES...",
    "MAPPING CAUSAL RELATIONSHIPS...",
    "SYNTHESIZING ROOT CAUSE HYPOTHESES...",
    "FINALIZING ANALYSIS..."
  ];

  useEffect(() => {
    // In static demo mode, we just ensure metrics are fresh
    const interval = setInterval(() => {
      setMetrics(prev => prev.map(m => ({
        ...m,
        value: m.isAnomaly ? 80 + Math.random() * 20 : 10 + Math.random() * 15
      })));
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (isAnalyzing) {
      const interval = setInterval(() => {
        setAnalysisStep(prev => (prev + 1) % analysisSteps.length);
      }, 1500);
      return () => clearInterval(interval);
    }
  }, [isAnalyzing]);

  const handleIncidentSelect = (incident: Incident) => {
    setSelectedIncident(incident);
    setActiveTab('analysis');
    if (incident.status !== 'resolved') {
      runAIAnalysis(incident);
    }
  };

  const triggerCrisis = async () => {
    setIsCrisisMode(true);
    
    const newIncident: Incident = {
      id: `INC-${Math.floor(Math.random() * 9000) + 1000}`,
      title: 'Global Edge Cache Poisoning',
      status: 'active',
      severity: 'P1',
      startTime: new Date().toISOString(),
      service: 'edge-cdn',
      description: 'Massive cache invalidation failure detected across all regions.',
      responders: [
        { name: 'Aaditi C.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aaditi', role: 'Lead SRE' }
      ]
    };

    setIncidents(prev => [newIncident, ...prev]);
    
    // Add crisis logs
    const crisisLog: LogEntry = {
      timestamp: new Date().toISOString(),
      level: 'ERROR',
      service: 'edge-cdn',
      message: 'Cache invalidation failed for key: global_auth_v2. Reason: Upstream checksum mismatch.',
      isSmokingGun: true,
      entities: [{ type: 'SERVICE', value: 'edge-cdn' }]
    };
    setLogs(prev => [crisisLog, ...prev]);

    setTimeout(() => {
      handleIncidentSelect(newIncident);
    }, 1000);
  };

  const runAIAnalysis = async (incident: Incident) => {
    setIsAnalyzing(true);
    setRcaResults([]);
    setAnalysisStep(0);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Analyze this IT incident and provide 3 ranked root cause hypotheses in JSON format.
        Incident: ${incident.title}
        Service: ${incident.service}
        Description: ${incident.description}
        
        Return an array of objects with: id, title, description, confidence (0-1), impact, isSmokingGun (boolean).`,
        config: {
          responseMimeType: "application/json"
        }
      });

      const data = JSON.parse(response.text || "[]");
      setRcaResults(data);
    } catch (error) {
      console.error("AI Analysis failed:", error);
      setRcaResults([
        { id: '1', title: 'Upstream Dependency Timeout', description: 'Payment gateway US-EAST-1 is experiencing 40% packet loss.', confidence: 0.85, impact: 'High', isSmokingGun: true },
        { id: '2', title: 'Resource Exhaustion', description: 'Checkout-api pod memory usage at 92%.', confidence: 0.45, impact: 'Medium' }
      ]);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleGenerateVideo = async () => {
    // Check for API Key
    const hasKey = await (window as any).aistudio.hasSelectedApiKey();
    if (!hasKey) {
      await (window as any).aistudio.openSelectKey();
      // Proceed after selection
    }

    setIsVideoGenerating(true);
    setVideoProgress("Initializing Veo Engine...");

    try {
      const prompt = "A cinematic, high-tech 3D animation of a futuristic AI cybersecurity command center. Holographic data streams and causal graphs float in the air, glowing in emerald and rose colors. The camera pans across a sleek, dark server room where an AI core is pulsing with light, representing real-time root cause analysis and incident resolution. Professional, clean, and high-fidelity.";
      
      let operation = await generateDemoVideo(prompt);
      setVideoProgress("Generating cinematic frames... (this may take 1-2 minutes)");

      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await checkVideoStatus(operation);
        
        // Randomize progress messages for better UX
        const messages = [
          "Synthesizing holographic data...",
          "Rendering causal graph animations...",
          "Optimizing AI command center visuals...",
          "Finalizing cinematic pan...",
          "Encoding MP4 for WhatsApp sharing..."
        ];
        setVideoProgress(messages[Math.floor(Math.random() * messages.length)]);
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        setVideoProgress("Downloading final video...");
        const blob = await downloadVideo(downloadLink);
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'OpsMind_Demo_Video.mp4';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error("Video generation failed:", error);
      alert("Video generation failed. Please ensure you have a valid billing-enabled API key selected.");
    } finally {
      setIsVideoGenerating(false);
      setVideoProgress(null);
    }
  };

  const filteredLogs = useMemo(() => {
    return filterSmokingGuns ? logs.filter(l => l.isSmokingGun) : logs;
  }, [filterSmokingGuns, logs]);

  const exportPostMortem = () => {
    alert("Generating Executive Post-Mortem Report...\n\n- Incident Timeline synthesized\n- Root Cause identified\n- Remediation steps documented\n- PDF ready for download.");
  };

  return (
    <div className={cn("min-h-screen flex flex-col transition-colors duration-1000", isCrisisMode && "crisis-mode")}>
      <div className="atmosphere" />
      
      {isDemoMode && (
        <div className="fixed inset-0 pointer-events-none z-[200] border-[20px] border-black/20 shadow-[inset_0_0_100px_rgba(0,0,0,0.5)]" />
      )}
      
      {isCrisisMode && (
        <div className="ticker-wrap">
          <div className="ticker">
            CRITICAL ALERT: GLOBAL EDGE CACHE POISONING DETECTED // SEVERITY: P1 // IMPACT: ALL REGIONS // RESPONDERS DISPATCHED // STANDBY FOR ANALYSIS...
          </div>
        </div>
      )}

      {/* Header */}
      <header className={cn("h-14 border-b border-white/10 flex items-center px-6 justify-between bg-black/40 backdrop-blur-xl sticky top-0 z-50 transition-all", isDemoMode && "h-12 opacity-80")}>
        <div className="flex items-center gap-3">
          <motion.div 
            animate={isCrisisMode ? { scale: [1, 1.2, 1], rotate: [0, 10, -10, 0] } : {}}
            transition={{ repeat: Infinity, duration: 0.5 }}
            className={cn("w-8 h-8 rounded flex items-center justify-center transition-colors", isCrisisMode ? "bg-rose-500" : "bg-emerald-500")}
          >
            <Zap className="text-black w-5 h-5 fill-current" />
          </motion.div>
          <div className="flex flex-col">
            <h1 className="font-mono font-bold tracking-tighter text-xl leading-none">OpsMind</h1>
            <span className="text-[8px] font-mono text-zinc-500 tracking-[0.3em] uppercase">AI Command Center</span>
          </div>
        </div>

        {/* Tab Navigation */}
        <nav className="flex items-center gap-1 bg-white/5 p-1 rounded-lg border border-white/5">
          {[
            { id: 'dashboard', label: 'DASHBOARD', icon: Activity },
            { id: 'analysis', label: 'ANALYSIS', icon: Zap, disabled: !selectedIncident },
            { id: 'telemetry', label: 'TELEMETRY', icon: Terminal },
            { id: 'graph', label: 'SYSTEM MAP', icon: Share2 },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => !tab.disabled && setActiveTab(tab.id as any)}
              disabled={tab.disabled}
              className={cn(
                "flex items-center gap-2 px-4 py-1.5 rounded-md text-[10px] font-mono font-bold transition-all",
                activeTab === tab.id 
                  ? "bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.4)]" 
                  : tab.disabled 
                    ? "text-zinc-600 cursor-not-allowed" 
                    : "text-zinc-400 hover:text-zinc-200 hover:bg-white/5"
              )}
            >
              <tab.icon className="w-3 h-3" />
              {tab.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-6 text-[10px] font-mono text-zinc-400">
            <div className="flex items-center gap-2">
              <div className={cn("w-2 h-2 rounded-full animate-pulse", isCrisisMode ? "bg-rose-500" : "bg-emerald-500")} />
              {isCrisisMode ? "CRISIS DETECTED" : "SYSTEMS NOMINAL"}
            </div>
            <div className="flex items-center gap-2">
              <Activity className="w-3 h-3" />
              {isCrisisMode ? "48.2k" : "12.4k"} REQ/S
            </div>
          </div>
          
          <button 
            onClick={() => setIsDemoMode(!isDemoMode)}
            className={cn(
              "p-1.5 rounded border transition-all",
              isDemoMode ? "bg-blue-500/20 text-blue-400 border-blue-500/30" : "bg-zinc-800 text-zinc-500 border-white/5 hover:text-zinc-300"
            )}
            title="Toggle Demo Mode"
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
          
          <button 
            onClick={triggerCrisis}
            className={cn(
              "px-4 py-1.5 rounded text-[10px] font-mono font-bold transition-all flex items-center gap-2",
              isCrisisMode 
                ? "bg-rose-500/20 text-rose-500 border border-rose-500/30 cursor-not-allowed" 
                : "bg-zinc-800 hover:bg-rose-600 text-zinc-300 hover:text-white border border-zinc-700"
            )}
            disabled={isCrisisMode}
          >
            <Flame className={cn("w-3 h-3", isCrisisMode && "animate-bounce")} />
            {isCrisisMode ? "SIMULATING CRISIS..." : "SIMULATE CRISIS"}
          </button>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden">
        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex-1 flex flex-col p-6 gap-6 overflow-y-auto"
            >
              {/* Stats Bar */}
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-xs font-mono font-bold text-zinc-500 tracking-widest uppercase">System Overview</h2>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={handleGenerateVideo}
                    disabled={isVideoGenerating}
                    className={cn(
                      "flex items-center gap-2 px-3 py-1 rounded border text-[10px] font-mono transition-all",
                      isVideoGenerating ? "bg-indigo-500/20 text-indigo-400 border-indigo-500/30" : "bg-indigo-500/10 border-indigo-500/20 text-indigo-400 hover:bg-indigo-500/20 hover:text-white"
                    )}
                  >
                    {isVideoGenerating ? (
                      <Loader2 className="w-3 h-3 animate-spin" />
                    ) : (
                      <Video className="w-3 h-3" />
                    )}
                    {isVideoGenerating ? "GENERATING VIDEO..." : "GENERATE DEMO MP4"}
                  </button>
                </div>
              </div>
              
              {videoProgress && (
                <div className="mb-4 p-3 rounded bg-indigo-500/10 border border-indigo-500/20 flex items-center gap-3">
                  <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />
                  <span className="text-[10px] font-mono text-indigo-300 uppercase tracking-wider">{videoProgress}</span>
                </div>
              )}
              <div className="grid grid-cols-4 gap-4">
                {[
                  { label: 'ACTIVE INCIDENTS', value: activeIncidents.length, color: isCrisisMode ? 'text-rose-500' : 'text-zinc-100', icon: AlertCircle },
                  { label: 'AVG MTTR', value: '42m', color: 'text-zinc-100', icon: Clock },
                  { label: 'HEALTH SCORE', value: isCrisisMode ? '64.2%' : '98.2%', color: isCrisisMode ? 'text-rose-500' : 'text-emerald-500', icon: ShieldCheck },
                  { label: 'AI CONFIDENCE', value: '89%', color: 'text-blue-500', icon: Zap },
                ].map((stat, i) => (
                  <div key={i} className="glass-panel p-4 flex flex-col gap-1 group hover:border-white/20 transition-colors">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono text-zinc-500 tracking-widest">{stat.label}</span>
                      <stat.icon className={cn("w-4 h-4 transition-transform group-hover:scale-110", stat.color)} />
                    </div>
                    <span className={cn("text-2xl font-bold font-mono", stat.color)}>{stat.value}</span>
                  </div>
                ))}
              </div>

              {/* Active Incidents Table */}
              <div className="glass-panel flex-1 flex flex-col overflow-hidden">
                <div className="p-4 border-b border-white/5 flex items-center justify-between bg-white/5">
                  <h2 className="font-mono text-xs font-bold flex items-center gap-2">
                    <Activity className={cn("w-4 h-4", isCrisisMode ? "text-rose-500" : "text-emerald-500")} />
                    INCIDENT COMMAND
                  </h2>
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <Search className="w-3 h-3 absolute left-2 top-1/2 -translate-y-1/2 text-zinc-500" />
                      <input 
                        type="text" 
                        placeholder="Search incidents..." 
                        className="bg-black/40 border border-white/10 rounded px-7 py-1 text-[10px] font-mono focus:outline-none focus:border-white/20 w-48"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col overflow-y-auto">
                  <div className="grid grid-cols-[100px_1fr_120px_120px_150px] bg-white/5">
                    <div className="col-header">ID</div>
                    <div className="col-header">TITLE</div>
                    <div className="col-header">SERVICE</div>
                    <div className="col-header">SEVERITY</div>
                    <div className="col-header">START TIME</div>
                  </div>
                  {activeIncidents.map((incident) => (
                    <motion.div 
                      layoutId={incident.id}
                      key={incident.id} 
                      className="data-grid-row"
                      onClick={() => handleIncidentSelect(incident)}
                    >
                      <div className="data-value text-zinc-500">{incident.id}</div>
                      <div className="font-medium text-sm truncate flex items-center gap-2">
                        {incident.severity === 'P1' && <Flame className="w-3 h-3 text-rose-500" />}
                        {incident.title}
                      </div>
                      <div className="data-value text-zinc-500">{incident.service}</div>
                      <div className="flex items-center gap-2">
                        <span className={cn(
                          "text-[10px] font-mono px-1.5 py-0.5 rounded border",
                          incident.severity === 'P1' ? "bg-rose-500/10 text-rose-500 border-rose-500/20" : "bg-amber-500/10 text-amber-500 border-amber-500/20"
                        )}>
                          {incident.severity}
                        </span>
                      </div>
                      <div className="data-value text-zinc-500">{new Date(incident.startTime).toLocaleTimeString()}</div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Resolved Incidents */}
              <div className="glass-panel h-48 flex flex-col opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition-all">
                <div className="p-3 border-b border-white/5">
                  <h2 className="font-mono text-[10px] font-bold text-zinc-500 tracking-widest">RECENTLY RESOLVED</h2>
                </div>
                <div className="flex-1 overflow-y-auto">
                  {resolvedIncidents.map((incident) => (
                    <div key={incident.id} className="flex items-center justify-between p-3 border-b border-white/5 text-xs">
                      <div className="flex items-center gap-3">
                        <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                        <span className="font-mono text-zinc-400">{incident.id}</span>
                        <span className="text-zinc-300">{incident.title}</span>
                      </div>
                      <span className="font-mono text-zinc-600">Resolved 2h ago</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'analysis' && selectedIncident && (
            <motion.div 
              key="analysis"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex flex-col overflow-hidden"
            >
              {/* Analysis Header */}
              <div className="h-14 border-b border-white/10 flex items-center px-6 gap-4 bg-black/40 backdrop-blur-xl">
                <button 
                  onClick={() => {
                    setSelectedIncident(null);
                    setActiveTab('dashboard');
                  }}
                  className="p-1.5 hover:bg-white/10 rounded-md transition-colors text-zinc-400 hover:text-white"
                  title="Back to Dashboard"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <div className="flex flex-col">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-zinc-500">{selectedIncident.id}</span>
                    <h2 className="text-sm font-bold">{selectedIncident.title}</h2>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[8px] font-mono text-zinc-500 uppercase tracking-widest">SERVICE: {selectedIncident.service}</span>
                    <span className="text-zinc-700">•</span>
                    <div className="flex items-center gap-1">
                      <Users className="w-2.5 h-2.5 text-zinc-500" />
                      <div className="flex -space-x-1.5">
                        {selectedIncident.responders?.map((r, i) => (
                          <img key={i} src={r.avatar} alt={r.name} className="w-4 h-4 rounded-full border border-black" title={`${r.name} (${r.role})`} />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="ml-auto flex items-center gap-3">
                  <button 
                    onClick={exportPostMortem}
                    className="flex items-center gap-2 px-3 py-1.5 rounded text-[10px] font-mono font-bold bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-white/5 transition-colors"
                  >
                    <Download className="w-3 h-3" />
                    EXPORT REPORT
                  </button>
                  <button className="bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-mono font-bold px-4 py-1.5 rounded transition-colors flex items-center gap-2">
                    <CheckCircle2 className="w-3 h-3" />
                    RESOLVE
                  </button>
                </div>
              </div>

              <div className="flex-1 flex overflow-hidden p-6 gap-6">
                {/* AI Analysis Section */}
                <div className="flex-1 flex flex-col gap-4 overflow-y-auto">
                  <div className="flex items-center justify-between">
                    <h3 className="font-mono text-[10px] font-bold text-zinc-500 tracking-widest flex items-center gap-2">
                      <Zap className="w-3 h-3 text-blue-500" />
                      AI CAUSAL ANALYSIS
                    </h3>
                    {isAnalyzing && (
                      <div className="flex items-center gap-3 text-[10px] font-mono text-blue-400">
                        <Activity className="w-3 h-3 animate-spin" />
                        {analysisSteps[analysisStep]}
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 gap-3">
                    <AnimatePresence mode="wait">
                      {isAnalyzing ? (
                        <motion.div 
                          key="analyzing"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="glass-panel p-8 flex flex-col items-center justify-center gap-4 min-h-[200px]"
                        >
                          <div className="relative w-16 h-16">
                            <div className="absolute inset-0 rounded-full border-2 border-blue-500/20" />
                            <div className="absolute inset-0 rounded-full border-t-2 border-blue-500 animate-spin" />
                            <Zap className="absolute inset-0 m-auto w-6 h-6 text-blue-500 animate-pulse" />
                          </div>
                          <div className="flex flex-col items-center gap-1">
                            <span className="text-[10px] font-mono text-blue-400 animate-pulse">NEURAL ENGINE ACTIVE</span>
                          </div>
                        </motion.div>
                      ) : (
                        rcaResults.map((hyp, i) => (
                          <motion.div 
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: i * 0.1 }}
                            key={hyp.id} 
                            className={cn(
                              "glass-panel p-4 border-l-4 transition-all cursor-pointer group relative overflow-hidden",
                              hyp.isSmokingGun ? "border-l-rose-500 bg-rose-500/5" : "border-l-blue-500 hover:bg-white/5"
                            )}
                          >
                            {hyp.isSmokingGun && (
                              <div className="absolute top-0 right-0 p-1 bg-rose-500 text-black text-[8px] font-bold font-mono">
                                SMOKING GUN
                              </div>
                            )}
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <h4 className={cn("text-sm font-bold transition-colors", hyp.isSmokingGun ? "text-rose-400" : "group-hover:text-blue-400")}>{hyp.title}</h4>
                                <p className="text-xs text-zinc-500 mt-1 leading-relaxed">{hyp.description}</p>
                              </div>
                              <div className="text-right">
                                <div className="text-[10px] font-mono text-zinc-500">CONFIDENCE</div>
                                <div className={cn("text-sm font-bold", hyp.isSmokingGun ? "text-rose-400" : "text-blue-400")}>{(hyp.confidence * 100).toFixed(0)}%</div>
                              </div>
                            </div>
                            <div className="flex items-center gap-4 mt-3 pt-3 border-t border-white/5">
                              <div className="flex items-center gap-1 text-[10px] font-mono text-zinc-500">
                                <AlertCircle className="w-3 h-3" />
                                IMPACT: <span className="text-zinc-300">{hyp.impact}</span>
                              </div>
                              <button className="ml-auto text-[10px] font-mono text-blue-500 hover:text-blue-400 flex items-center gap-1 transition-colors">
                                VIEW EVIDENCE <ChevronRight className="w-3 h-3" />
                              </button>
                            </div>
                          </motion.div>
                        ))
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                {/* Mini Graph in Analysis Tab */}
                <div className="w-[400px] flex flex-col gap-4">
                  <h3 className="font-mono text-[10px] font-bold text-zinc-500 tracking-widest flex items-center gap-2">
                    <Share2 className="w-3 h-3 text-emerald-500" />
                    LOCAL CAUSAL GRAPH
                  </h3>
                  <div className="glass-panel flex-1 relative overflow-hidden bg-black/20">
                    <KnowledgeGraph data={MOCK_GRAPH_DATA} />
                  </div>
                  <div className="glass-panel p-4 flex flex-col gap-2">
                    <h4 className="text-[10px] font-mono font-bold text-zinc-400">QUICK ACTIONS</h4>
                    <button className="w-full py-2 rounded bg-blue-600 hover:bg-blue-500 text-[10px] font-mono font-bold text-white transition-colors">
                      EXECUTE REMEDIATION
                    </button>
                    <button className="w-full py-2 rounded bg-zinc-800 hover:bg-zinc-700 text-[10px] font-mono font-bold text-zinc-300 border border-white/5">
                      PAGE ON-CALL TEAM
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'telemetry' && (
            <motion.div 
              key="telemetry"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex-1 flex overflow-hidden p-6 gap-6"
            >
              {/* Left: Metrics */}
              <div className="flex-1 flex flex-col gap-6">
                <div className="glass-panel p-6 flex flex-col gap-4">
                  <h3 className="font-mono text-[10px] font-bold text-zinc-500 tracking-widest flex items-center justify-between">
                    SYSTEM TELEMETRY
                    <span className="text-rose-500 animate-pulse">LIVE FEED</span>
                  </h3>
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={metrics}>
                        <defs>
                          <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={isCrisisMode ? "#f43f5e" : "#10b981"} stopOpacity={0.3}/>
                            <stop offset="95%" stopColor={isCrisisMode ? "#f43f5e" : "#10b981"} stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <XAxis dataKey="time" hide />
                        <YAxis hide domain={['auto', 'auto']} />
                        <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} opacity={0.1} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#000', border: '1px solid #333', fontSize: '10px', fontFamily: 'monospace' }}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="value" 
                          stroke={isCrisisMode ? "#f43f5e" : "#10b981"} 
                          fillOpacity={1} 
                          fill="url(#colorValue)" 
                          strokeWidth={3}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  {[
                    { label: 'CPU LOAD', value: isCrisisMode ? '84%' : '12%', trend: '+12%', color: isCrisisMode ? 'text-rose-500' : 'text-emerald-500' },
                    { label: 'MEM USAGE', value: isCrisisMode ? '92%' : '45%', trend: '+5%', color: isCrisisMode ? 'text-rose-500' : 'text-emerald-500' },
                    { label: 'LATENCY', value: isCrisisMode ? '1.2s' : '42ms', trend: '+800%', color: isCrisisMode ? 'text-rose-500' : 'text-emerald-500' },
                    { label: 'ERROR RATE', value: isCrisisMode ? '14.2%' : '0.01%', trend: '+1400%', color: isCrisisMode ? 'text-rose-500' : 'text-emerald-500' },
                    { label: 'DISK I/O', value: '240MB/s', trend: 'STABLE', color: 'text-zinc-400' },
                    { label: 'NET THROUGHPUT', value: '1.2GB/s', trend: 'STABLE', color: 'text-zinc-400' },
                  ].map((m, i) => (
                    <div key={i} className="glass-panel p-4 flex flex-col gap-1">
                      <div className="text-[9px] font-mono text-zinc-500 tracking-widest uppercase">{m.label}</div>
                      <div className={cn("text-xl font-bold font-mono", m.color)}>{m.value}</div>
                      <div className="text-[8px] font-mono opacity-60">{m.trend}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right: Log Stream */}
              <div className="w-[500px] glass-panel flex flex-col overflow-hidden terminal-glow">
                <div className="p-4 border-b border-white/5 flex items-center justify-between bg-white/5">
                  <h3 className="font-mono text-[10px] font-bold text-zinc-500 tracking-widest">REAL-TIME LOG STREAM</h3>
                  <button 
                    onClick={() => setFilterSmokingGuns(!filterSmokingGuns)}
                    className={cn(
                      "flex items-center gap-1.5 px-2 py-1 rounded text-[8px] font-mono border transition-all",
                      filterSmokingGuns 
                        ? "bg-rose-500/20 text-rose-500 border-rose-500/30" 
                        : "bg-zinc-800 text-zinc-500 border-white/5 hover:text-zinc-300"
                    )}
                  >
                    <Filter className="w-2.5 h-2.5" />
                    {filterSmokingGuns ? "SMOKING GUNS ONLY" : "ALL LOGS"}
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 font-mono text-[10px] flex flex-col gap-3">
                  {filteredLogs.map((log, i) => (
                    <motion.div 
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      key={i} 
                      className={cn(
                        "flex flex-col gap-1 p-2 rounded border transition-colors",
                        log.isSmokingGun ? "bg-rose-500/10 border-rose-500/20" : "bg-white/5 border-white/5"
                      )}
                    >
                      <div className="flex items-center justify-between text-[8px] text-zinc-600">
                        <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
                        <span className={cn(
                          log.level === 'ERROR' ? "text-rose-500" : "text-amber-500"
                        )}>{log.level}</span>
                      </div>
                      <div className="text-zinc-300 leading-relaxed">
                        {log.message}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'graph' && (
            <motion.div 
              key="graph"
              initial={{ opacity: 0, scale: 1.05 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex-1 relative overflow-hidden"
            >
              <KnowledgeGraph data={MOCK_GRAPH_DATA} />
              
              <div className="absolute top-6 left-6 glass-panel p-4 flex flex-col gap-4 pointer-events-none">
                <h3 className="font-mono text-[10px] font-bold text-zinc-500 tracking-widest">SYSTEM TOPOLOGY</h3>
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-2 text-[10px] font-mono text-zinc-400">
                    <div className="w-3 h-3 rounded-full bg-rose-500" />
                    CRITICAL FAILURE
                  </div>
                  <div className="flex items-center gap-2 text-[10px] font-mono text-zinc-400">
                    <div className="w-3 h-3 rounded-full bg-emerald-500" />
                    HEALTHY NODE
                  </div>
                  <div className="flex items-center gap-2 text-[10px] font-mono text-zinc-400">
                    <div className="w-3 h-3 rounded-full bg-blue-500" />
                    AI RECOMMENDED FIX
                  </div>
                </div>
              </div>

              <div className="absolute bottom-6 right-6 glass-panel p-4 flex items-center gap-6 pointer-events-none">
                <div className="flex flex-col">
                  <span className="text-[8px] font-mono text-zinc-500">NODES</span>
                  <span className="text-xl font-bold font-mono">142</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[8px] font-mono text-zinc-500">EDGES</span>
                  <span className="text-xl font-bold font-mono">384</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[8px] font-mono text-zinc-500">ISOLATED</span>
                  <span className="text-xl font-bold font-mono text-rose-500">3</span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Demo Controls Floating Panel */}
      {!isDemoMode && (
        <motion.div 
          drag
          dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
          className="fixed bottom-12 right-6 z-[100] glass-panel p-3 flex flex-col gap-2 w-48 shadow-2xl border-blue-500/20"
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-[9px] font-mono font-bold text-blue-400 tracking-widest">DEMO CONTROLS</span>
            <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
          </div>
          <button 
            onClick={triggerCrisis}
            disabled={isCrisisMode}
            className="w-full py-1.5 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 text-[9px] font-mono font-bold border border-rose-500/20 transition-all flex items-center justify-center gap-2"
          >
            <Flame className="w-3 h-3" /> TRIGGER P1 CRISIS
          </button>
          <button 
            onClick={() => {
              setIncidents(MOCK_INCIDENTS);
              setIsCrisisMode(false);
              setSelectedIncident(null);
              setActiveTab('dashboard');
            }}
            className="w-full py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-400 text-[9px] font-mono font-bold border border-white/5 transition-all"
          >
            RESET ENVIRONMENT
          </button>
          <div className="h-px bg-white/5 my-1" />
          <div className="flex items-center justify-between px-1">
            <span className="text-[8px] font-mono text-zinc-500 uppercase">Auto-Analysis</span>
            <div className="w-6 h-3 bg-blue-600 rounded-full relative cursor-pointer">
              <div className="absolute right-0.5 top-0.5 w-2 h-2 bg-white rounded-full" />
            </div>
          </div>
        </motion.div>
      )}

      {/* Footer */}
      {!isDemoMode && (
        <footer className="h-8 border-t border-white/5 bg-black flex items-center px-6 justify-between text-[9px] font-mono text-zinc-500">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <Database className="w-3 h-3" />
            DB: CLUSTER-01 (PRIMARY)
          </div>
          <div className="flex items-center gap-1.5">
            <Cpu className="w-3 h-3" />
            CPU: {isCrisisMode ? "82%" : "14%"}
          </div>
          <div className="flex items-center gap-1.5">
            <Users className="w-3 h-3" />
            {isCrisisMode ? "12" : "4"} ACTIVE RESPONDERS
          </div>
        </div>
          <div className="flex items-center gap-4">
            <span className="text-zinc-600">BUILD: 2026.03.14.REV_5</span>
            <div className="flex items-center gap-2">
              <div className={cn("w-1.5 h-1.5 rounded-full", isBackendConnected ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" : "bg-rose-500")} />
              <span className="text-zinc-400 uppercase tracking-tighter">Backend: {isBackendConnected ? "Connected" : "Disconnected"}</span>
            </div>
            <span className={cn("transition-colors font-bold", isCrisisMode ? "text-rose-500" : "text-emerald-500")}>
              {isCrisisMode ? "CRITICAL STATE" : "SECURE CONNECTION"}
            </span>
          </div>
      </footer>
      )}
    </div>
  );
}

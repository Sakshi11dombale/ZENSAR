import { Incident, LogEntry, MetricPoint, GraphNode, GraphLink } from './types';

export const MOCK_INCIDENTS: Incident[] = [
  {
    id: 'INC-8821',
    title: 'Checkout Service Latency Spike',
    status: 'active',
    severity: 'P1',
    startTime: new Date(Date.now() - 45 * 60000).toISOString(),
    service: 'checkout-api',
    description: 'P99 latency increased from 200ms to 4.5s in US-EAST-1.',
    responders: [
      { name: 'Aaditi C.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aaditi', role: 'Lead SRE' },
      { name: 'Marcus K.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Marcus', role: 'DevOps' }
    ]
  },
  {
    id: 'INC-8819',
    title: 'Database Connection Pool Exhaustion',
    status: 'investigating',
    severity: 'P2',
    startTime: new Date(Date.now() - 120 * 60000).toISOString(),
    service: 'user-db-cluster',
    description: 'User service reporting 500 errors due to DB connection timeouts.',
    responders: [
      { name: 'Sarah L.', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah', role: 'DBA' }
    ]
  },
  {
    id: 'INC-8815',
    title: 'Auth Token Validation Failure',
    status: 'resolved',
    severity: 'P2',
    startTime: new Date(Date.now() - 300 * 60000).toISOString(),
    service: 'auth-v2',
    description: 'Intermittent token validation failures after v2.4.1 deployment.'
  }
];

export const MOCK_LOGS: LogEntry[] = [
  {
    timestamp: '2026-03-14T11:02:15Z',
    level: 'ERROR',
    service: 'checkout-api',
    message: 'Timeout connecting to payment-gateway at 10.0.45.12',
    isSmokingGun: true,
    entities: [
      { type: 'SERVICE', value: 'payment-gateway' },
      { type: 'IP', value: '10.0.45.12' }
    ]
  },
  {
    timestamp: '2026-03-14T11:02:18Z',
    level: 'WARN',
    service: 'checkout-api',
    message: 'Retrying request to payment-gateway (Attempt 3/3)',
    entities: [{ type: 'SERVICE', value: 'payment-gateway' }]
  },
  {
    timestamp: '2026-03-14T11:02:20Z',
    level: 'ERROR',
    service: 'checkout-api',
    message: 'Circuit breaker opened for payment-gateway. Error code: ERR_GATEWAY_TIMEOUT',
    isSmokingGun: true,
    entities: [
      { type: 'SERVICE', value: 'payment-gateway' },
      { type: 'ERROR_CODE', value: 'ERR_GATEWAY_TIMEOUT' }
    ]
  },
  {
    timestamp: '2026-03-14T11:02:22Z',
    level: 'INFO',
    service: 'checkout-api',
    message: 'Health check passed for secondary-gateway',
  }
];

export const MOCK_METRICS: MetricPoint[] = Array.from({ length: 24 }, (_, i) => ({
  time: `${i}:00`,
  value: i > 18 && i < 22 ? 80 + Math.random() * 20 : 10 + Math.random() * 15,
  isAnomaly: i > 18 && i < 22
}));

export const MOCK_GRAPH_DATA: { nodes: GraphNode[], links: GraphLink[] } = {
  nodes: [
    { id: 'checkout-api', type: 'service', label: 'Checkout API', status: 'critical' },
    { id: 'payment-gateway', type: 'service', label: 'Payment Gateway', status: 'warning' },
    { id: 'user-db', type: 'database', label: 'User DB', status: 'healthy' },
    { id: 'timeout-error', type: 'error', label: 'Gateway Timeout' },
    { id: 'scale-fix', type: 'fix', label: 'Scale Replicas' }
  ],
  links: [
    { source: 'checkout-api', target: 'payment-gateway', value: 1 },
    { source: 'payment-gateway', target: 'timeout-error', value: 2 },
    { source: 'timeout-error', target: 'scale-fix', value: 1 },
    { source: 'checkout-api', target: 'user-db', value: 1 }
  ]
};
